package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.db.PyboxDatabase
import com.example.db.VoiceCommandLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

object PyboxEngine : TextToSpeech.OnInitListener {
    private const val TAG = "PyboxEngine"

    private val _currentMode = MutableStateFlow(PyboxMode.ECO)
    val currentMode: StateFlow<PyboxMode> = _currentMode.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _activeCommandText = MutableStateFlow("")
    val activeCommandText: StateFlow<String> = _activeCommandText.asStateFlow()

    private val _statusMessage = MutableStateFlow("Initialized & Ready.")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _recentLogs = MutableStateFlow<List<VoiceCommandLog>>(emptyList())
    val recentLogs: StateFlow<List<VoiceCommandLog>> = _recentLogs.asStateFlow()

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    private val okHttpClientByPass = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
        observeHistoryLogs(context)
    }

    private fun observeHistoryLogs(context: Context) {
        coroutineScope.launch {
            val db = PyboxDatabase.getDatabase(context)
            db.commandDao().getAllLogs().collect { logs ->
                _recentLogs.value = logs
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { textToSpeech ->
                val result = textToSpeech.setLanguage(Locale.getAvailableLocales().firstOrNull { it.language == Locale.ENGLISH.language } ?: Locale.US)
                if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                    isTtsInitialized = true
                    textToSpeech.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }
                    })
                    speak("Pybox Core operational. Mode set to ECO.", isSystemInit = true)
                }
            }
        } else {
            Log.e(TAG, "TTS Initialization failed")
        }
    }

    fun setMode(mode: PyboxMode) {
        _currentMode.value = mode
        updateVoiceConfig(mode)
        _statusMessage.value = "Active Mode: ${mode.displayName}"
        speak("Switching to system profile: ${mode.displayName}.")
    }

    private fun updateVoiceConfig(mode: PyboxMode) {
        tts?.let {
            when (mode) {
                PyboxMode.ECO -> {
                    it.setPitch(0.9f)
                    it.setSpeechRate(1.0f)
                }
                PyboxMode.HARD_WORK -> {
                    it.setPitch(1.0f)
                    it.setSpeechRate(1.25f)
                }
                PyboxMode.FRIENDLY -> {
                    it.setPitch(1.15f)
                    it.setSpeechRate(1.1f)
                }
                PyboxMode.HYPER_TECH -> {
                    it.setPitch(0.75f)
                    it.setSpeechRate(1.2f)
                }
            }
        }
    }

    fun setListening(listening: Boolean) {
        _isListening.value = listening
        if (listening) {
            _activeCommandText.value = ""
            _statusMessage.value = "Listening continuously..."
        } else {
            _statusMessage.value = "Standby mode."
        }
    }

    fun updateActiveCommandText(text: String) {
        _activeCommandText.value = text
    }

    fun speak(text: String, isSystemInit: Boolean = false) {
        if (isTtsInitialized) {
            if (!isSystemInit) {
                updateVoiceConfig(_currentMode.value)
            }
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "pybox_speak")
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "pybox_speak")
        }
    }

    fun processCommand(context: Context, fullSpokenText: String) {
        val sanitized = fullSpokenText.trim()
        if (sanitized.isEmpty()) return

        _activeCommandText.value = sanitized
        _isProcessing.value = true
        _statusMessage.value = "Processing intent..."

        coroutineScope.launch {
            try {
                val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                var actionType = "GENERAL_ASSISTANT"
                var target = ""
                var value = ""
                var speechResponse = ""

                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    Log.d(TAG, "Using smart local rule fallback parsing (Offline Mode)")
                    val offlineResult = handleLocalCommandFallback(sanitized)
                    actionType = offlineResult.actionType
                    target = offlineResult.target
                    value = offlineResult.value
                    speechResponse = offlineResult.speechResponse
                } else {
                    val systemInstruction = """
                        You are Pybox, an advanced voice-first AI assistant.
                        Act exactly in accordance with the current personality mode: ${_currentMode.value.id}.
                        
                        You MUST respond in a valid JSON format.
                        JSON Schema:
                        {
                          "action": "OPEN_APP | CALL_PHONE | SEND_MESSAGE | CONTROL_SETTING | WEB_SEARCH | SWITCH_MODE | GENERAL_ASSISTANT",
                          "arguments": {
                            "target": "the name of app, contact name, phone number, setting, or search query",
                            "value": "the state, message text, or profile identifier (ECO, HARD_WORK, FRIENDLY, HYPER_TECH)"
                          },
                          "speech_response": "The spoken voice response to reply back to the user"
                        }
                        
                        PERSONALITY CHARACTERISTICS:
                        - ECO (Default): Calm, professional, J.A.R.V.I.S.-like, witty.
                        - HARD_WORK: Cold, functional, direct, ultra-efficient.
                        - FRIENDLY: Casual, conversational, warm, helper-like.
                        - HYPER_TECH: Cyberpunk style, aggressive, sparse speech, robotic/minimal jargon.
                        
                        Return absolutely nothing other than the valid raw JSON object.
                    """.trimIndent()

                    val prompt = "User Command: \"$sanitized\""
                    
                    val responseJsonStr = fetchGeminiResponse(apiKey, systemInstruction, prompt)
                    if (responseJsonStr != null) {
                        try {
                            val json = JSONObject(responseJsonStr)
                            actionType = json.optString("action", "GENERAL_ASSISTANT")
                            val args = json.optJSONObject("arguments")
                            if (args != null) {
                                target = args.optString("target", "")
                                value = args.optString("value", "")
                            }
                            speechResponse = json.optString("speech_response", "Command received, processing.")
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing Gemini response, falling back to local parsing", e)
                            val offlineResult = handleLocalCommandFallback(sanitized)
                            actionType = offlineResult.actionType
                            target = offlineResult.target
                            value = offlineResult.value
                            speechResponse = offlineResult.speechResponse
                        }
                    } else {
                        val offlineResult = handleLocalCommandFallback(sanitized)
                        actionType = offlineResult.actionType
                        target = offlineResult.target
                        value = offlineResult.value
                        speechResponse = offlineResult.speechResponse
                    }
                }

                speechResponse = applyThemeProfileVoiceDecoration(speechResponse)

                _statusMessage.value = "Executing action..."
                executeNativeAction(context, actionType, target, value)

                speak(speechResponse)

                saveLogToDb(context, sanitized, speechResponse, actionType, target)

            } catch (e: Exception) {
                Log.e(TAG, "Error in processing: ", e)
                _statusMessage.value = "System processing interruption."
                speak("Interruption in command processor, system operational.")
            } finally {
                _isProcessing.value = false
            }
        }
    }

    private suspend fun fetchGeminiResponse(apiKey: String, systemInstruction: String, prompt: String): String? = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val mediaType = "application/json".toMediaType()

        val jsonPayload = JSONObject().apply {
            put("contents", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemInstruction)
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonPayload.toString().toRequestBody(mediaType))
            .build()

        try {
            val response = okHttpClientByPass.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: return@withContext null
                val rootJson = JSONObject(body)
                val candidates = rootJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text")
                    }
                }
            } else {
                Log.e(TAG, "Gemini API error: ${response.code} : ${response.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Connection exception", e)
        }
        return@withContext null
    }

    private fun applyThemeProfileVoiceDecoration(rawResponse: String): String {
        return when (_currentMode.value) {
            PyboxMode.ECO -> "Sir, $rawResponse"
            PyboxMode.HARD_WORK -> "COMMAND HANDLED: $rawResponse"
            PyboxMode.FRIENDLY -> "$rawResponse"
            PyboxMode.HYPER_TECH -> "CORE >> $rawResponse"
        }
    }

    private fun handleLocalCommandFallback(command: String): LocalCommandResult {
        val lowercase = command.lowercase(Locale.ROOT)
        
        return when {
            lowercase.contains("switch mode") || lowercase.contains("set mode") || lowercase.contains("profile") -> {
                val targetMode = when {
                    lowercase.contains("eco") -> "ECO"
                    lowercase.contains("hard work") || lowercase.contains("hardwork") -> "HARD_WORK"
                    lowercase.contains("friendly") -> "FRIENDLY"
                    lowercase.contains("hyper tech") || lowercase.contains("hypertech") || lowercase.contains("red") -> "HYPER_TECH"
                    else -> ""
                }
                if (targetMode.isNotEmpty()) {
                    LocalCommandResult(
                        "SWITCH_MODE",
                        targetMode,
                        "",
                        "Switching profiles to $targetMode as requested."
                    )
                } else {
                    LocalCommandResult(
                        "GENERAL_ASSISTANT",
                        "",
                        "",
                        "Provide a valid mode: ECO, HARD WORK, FRIENDLY, or HYPER-TECH."
                    )
                }
            }
            lowercase.contains("open") -> {
                val appNameSpoken = lowercase.substringAfter("open").trim()
                LocalCommandResult(
                    "OPEN_APP",
                    appNameSpoken,
                    "",
                    "Opening $appNameSpoken."
                )
            }
            lowercase.contains("call") -> {
                val contactSpoken = lowercase.substringAfter("call").trim()
                LocalCommandResult(
                    "CALL_PHONE",
                    contactSpoken,
                    "",
                    "Initiating call to $contactSpoken."
                )
            }
            lowercase.contains("message") || lowercase.contains("sms") || lowercase.contains("text") -> {
                val components = lowercase.substringAfter("message").trim()
                val targetName = components.substringBefore("body").substringBefore("saying").trim()
                val contentText = if (components.contains("body")) {
                    components.substringAfter("body").trim()
                } else if (components.contains("saying")) {
                    components.substringAfter("saying").trim()
                } else {
                    "Default Pybox automatic message."
                }
                LocalCommandResult(
                    "SEND_MESSAGE",
                    targetName,
                    contentText,
                    "Drafting message to $targetName."
                )
            }
            lowercase.contains("wifi") || lowercase.contains("wi-fi") || lowercase.contains("bluetooth") -> {
                val setting = if (lowercase.contains("wifi") || lowercase.contains("wi-fi")) "WiFi" else "Bluetooth"
                val state = if (lowercase.contains("off") || lowercase.contains("disable")) "off" else "on"
                LocalCommandResult(
                    "CONTROL_SETTING",
                    setting,
                    state,
                    "Accessing wireless controls for $setting."
                )
            }
            lowercase.contains("search") || lowercase.contains("google") || lowercase.contains("web") -> {
                val query = lowercase.substringAfter("search").substringAfter("google").trim()
                LocalCommandResult(
                    "WEB_SEARCH",
                    query,
                    "",
                    "Launching digital web search for $query."
                )
            }
            else -> {
                LocalCommandResult(
                    "GENERAL_ASSISTANT",
                    "",
                    "",
                    "Pybox Sandbox offline processor. Gemini API Key is missing. I understood: $lowercase."
                )
            }
        }
    }

    private fun executeNativeAction(context: Context, action: String, target: String, value: String) {
        val mainHandler = android.os.Handler(context.mainLooper)
        mainHandler.post {
            try {
                when (action.uppercase(Locale.ROOT)) {
                    "SWITCH_MODE" -> {
                        val uppercaseMode = target.uppercase(Locale.ROOT).replace(" ", "_")
                        val modeToSet = PyboxMode.values().firstOrNull { it.id == uppercaseMode || it.name == uppercaseMode }
                        modeToSet?.let {
                            _currentMode.value = it
                            updateVoiceConfig(it)
                            _statusMessage.value = "Profile changed: ${it.displayName}"
                        }
                    }
                    "OPEN_APP" -> {
                        val appFound = openApplicationByName(context, target)
                        if (!appFound) {
                            // Launch standard fallback query on app store or open generic settings
                            val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                    }
                    "CALL_PHONE" -> {
                        val number = target.filter { it.isDigit() }
                        if (number.isNotEmpty()) {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } else {
                            // Contact name lookup or general Dialer
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                    }
                    "SEND_MESSAGE" -> {
                        val telNumber = target.filter { it.isDigit() }.ifEmpty { "5556" }
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("smsto:$telNumber")
                            putExtra("sms_body", value.ifEmpty { "A transmission from Pybox" })
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    }
                    "CONTROL_SETTING" -> {
                        if (target.contains("Bluetooth", ignoreCase = true)) {
                            val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } else {
                            val intent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }
                    }
                    "WEB_SEARCH" -> {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(target)}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to execute native visual action: ", e)
            }
        }
    }

    private fun openApplicationByName(context: Context, targetAppName: String): Boolean {
        val pm = context.packageManager
        val list = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (info in list) {
            val label = pm.getApplicationLabel(info).toString().lowercase(Locale.ROOT)
            val search = targetAppName.lowercase(Locale.ROOT)
            if (label.contains(search) || search.contains(label)) {
                val launchIntent = pm.getLaunchIntentForPackage(info.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return true
                }
            }
        }
        return false
    }

    private fun saveLogToDb(context: Context, command: String, response: String, action: String, target: String) {
        coroutineScope.launch {
            try {
                val db = PyboxDatabase.getDatabase(context)
                val logItem = VoiceCommandLog(
                    textSpoken = command,
                    responseText = response,
                    mode = _currentMode.value.displayName,
                    actionType = action,
                    actionTarget = target
                )
                db.commandDao().insertLog(logItem)
            } catch (e: Exception) {
                Log.e(TAG, "DB Save error: ", e)
            }
        }
    }

    fun clearLogHistory(context: Context) {
        coroutineScope.launch {
            try {
                val db = PyboxDatabase.getDatabase(context)
                db.commandDao().clearLogs()
            } catch (e: Exception) {
                Log.e(TAG, "DB clear error: ", e)
            }
        }
    }

    data class LocalCommandResult(
        val actionType: String,
        val target: String,
        val value: String,
        val speechResponse: String
    )
}
