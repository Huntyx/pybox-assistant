package com.example

import androidx.compose.ui.graphics.Color

enum class PyboxMode(
    val id: String,
    val displayName: String,
    val color: Color,
    val glowColor: Color,
    val description: String,
    val accentHex: String
) {
    ECO(
        id = "ECO",
        displayName = "Pybox ECO",
        color = Color(0xFFFF9100),
        glowColor = Color(0x33FF9100),
        description = "Calm, professional, JARVIS-like.",
        accentHex = "#FF9100"
    ),
    HARD_WORK(
        id = "HARD_WORK",
        displayName = "Pybox HARD WORK",
        color = Color(0xFF00B0FF),
        glowColor = Color(0x3300B0FF),
        description = "Cold, direct, ultra-efficient.",
        accentHex = "#00B0FF"
    ),
    FRIENDLY(
        id = "FRIENDLY",
        displayName = "Pybox FRIENDLY",
        color = Color(0xFF00E676),
        glowColor = Color(0x3300E676),
        description = "Casual, conversational, warm.",
        accentHex = "#00E676"
    ),
    HYPER_TECH(
        id = "HYPER_TECH",
        displayName = "Pybox HYPER_TECH",
        color = Color(0xFFFF1744),
        glowColor = Color(0x33FF1744),
        description = "Aggressive, minimal, hacker-style.",
        accentHex = "#FF1744"
    )
}
