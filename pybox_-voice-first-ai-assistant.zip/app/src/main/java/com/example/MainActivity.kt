package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.db.VoiceCommandLog
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize().background(Color(0xFF090C15)),
                    contentWindowInsets = WindowInsets(0, 0, 0, 0)
                ) { innerPadding ->
                    PyboxAppScreen(
                        modifier = Modifier.padding(innerPadding),
                        onStartService = { startVoiceService(this) },
                        onStopService = { stopVoiceService(this) }
                    )
                }
            }
        }
    }

    private fun startVoiceService(context: Context) {
        val intent = Intent(context, PyboxVoiceService::class.java).apply {
            action = PyboxVoiceService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        Log.d(TAG, "Voice continuous service started")
    }

    private fun stopVoiceService(context: Context) {
        val intent = Intent(context, PyboxVoiceService::class.java).apply {
            action = PyboxVoiceService.ACTION_STOP
        }
        context.stopService(intent)
        Log.d(TAG, "Voice continuous service stopped")
    }
}

@Composable
fun PyboxAppScreen(
    modifier: Modifier = Modifier,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Engine UI States
    val mode by PyboxEngine.currentMode.collectAsState()
    val isListening by PyboxEngine.isListening.collectAsState()
    val isProcessing by PyboxEngine.isProcessing.collectAsState()
    val isSpeaking by PyboxEngine.isSpeaking.collectAsState()
    val activeCommandText by PyboxEngine.activeCommandText.collectAsState()
    val statusMessage by PyboxEngine.statusMessage.collectAsState()
    val recentLogs by PyboxEngine.recentLogs.collectAsState()

    var textInputState by remember { mutableStateOf("") }
    var micPermissionGranted by remember { mutableStateOf(false) }
    var notificationPermissionGranted by remember { mutableStateOf(true) }

    // Check Permissions
    LaunchedEffect(Unit) {
        micPermissionGranted = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionGranted = context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        }
        PyboxEngine.init(context)
    }

    // Permission Launchers
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        micPermissionGranted = perms[Manifest.permission.RECORD_AUDIO] == true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionGranted = perms[Manifest.permission.POST_NOTIFICATIONS] == true
        }

        if (micPermissionGranted) {
            Toast.makeText(context, "Microphone Access Authorized", Toast.LENGTH_SHORT).show()
            onStartService()
        } else {
            Toast.makeText(context, "Voice features require Microphone permission.", Toast.LENGTH_LONG).show()
        }
    }

    // Setup first run service trigger
    LaunchedEffect(micPermissionGranted) {
        if (micPermissionGranted) {
            onStartService()
        }
    }

    val bgGradient = remember(mode, isProcessing, isListening) {
        Brush.radialGradient(
            colors = listOf(
                mode.color.copy(alpha = if (isProcessing) 0.35f else if (isListening) 0.25f else 0.15f),
                Color(0xFF04060A)
            ),
            radius = 1200f
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgGradient)
            .padding(horizontal = 24.dp, vertical = 32.dp)
    ) {
        
        // 1. Center Focal Point: Animated Core Visualizer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 160.dp), // Leaves room for UI at the bottom
            contentAlignment = Alignment.Center
        ) {
            PyboxCoreVisualizer(
                mode = mode,
                isListening = isListening,
                isProcessing = isProcessing,
                isSpeaking = isSpeaking,
                activeText = activeCommandText
            )
        }

        // 2. Top UI: Clean Header and Mode Selector
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "PYBOX SYSTEM ///",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 4.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "PROFILE: ${mode.id}",
                        color = mode.color.copy(alpha = 0.8f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                }

                IconButton(
                    onClick = {
                        if (!micPermissionGranted) {
                            val list = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                list.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permissionLauncher.launch(list.toTypedArray())
                        } else {
                            onStopService()
                            scope.launch {
                                kotlinx.coroutines.delay(400)
                                onStartService()
                                Toast.makeText(context, "Pybox Voice Core Restarted", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(mode.color.copy(alpha = 0.1f))
                        .testTag("power_cycle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Restart engine",
                        tint = mode.color,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sleek Mode Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PyboxMode.values().forEach { m ->
                    val isSelected = mode == m
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(28.dp))
                            .background(if (isSelected) m.color.copy(alpha = 0.2f) else Color.Transparent)
                            .clickable { PyboxEngine.setMode(m) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = m.id.take(4).uppercase(), // Shortened names for minimal look
                            color = if (isSelected) m.color else Color.White.copy(alpha = 0.4f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 3. Bottom UI: Live Terminal, History, and Text Input overrides
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
        ) {
            // Semi-transparent log container (Shows only latest log if not empty)
            AnimatedVisibility(visible = recentLogs.isNotEmpty(), enter = fadeIn(), exit = fadeOut()) {
                val latestLog = recentLogs.firstOrNull()
                if (latestLog != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.02f))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    text = "LAST COMMAND | ${latestLog.actionType}",
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "CLR ✕",
                                    color = mode.color.copy(alpha = 0.6f),
                                    fontSize = 9.sp,
                                    modifier = Modifier.clickable { PyboxEngine.clearLogHistory(context) }
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "» ${latestLog.textSpoken}",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${latestLog.responseText}",
                                color = mode.color.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Glassmorphic Terminal Status
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isSpeaking -> mode.color
                                            isProcessing -> Color.Yellow
                                            isListening -> Color.Red
                                            else -> Color.White.copy(alpha = 0.2f)
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    isSpeaking -> "TRANSMITTING."
                                    isProcessing -> "ANALYZING..."
                                    isListening -> "LISTENING..."
                                    else -> "STANDBY."
                                },
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 2.sp
                            )
                        }
                        Text(
                            text = "HOTWORD: PYBOX",
                            color = Color.White.copy(alpha = 0.3f),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = activeCommandText.ifEmpty { "Awaiting voice command..." },
                        color = if (activeCommandText.isEmpty()) Color.White.copy(alpha = 0.2f) else Color.White,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("terminal_subtitle_ticker")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sandbox Console Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInputState,
                    onValueChange = { textInputState = it },
                    placeholder = { Text("Override command...", color = Color.White.copy(alpha = 0.2f), fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )

                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(mode.color.copy(alpha = 0.2f))
                        .clickable {
                            if (textInputState.trim().isNotEmpty()) {
                                PyboxEngine.processCommand(context, textInputState)
                                textInputState = ""
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = mode.color,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PyboxCoreVisualizer(
    mode: PyboxMode,
    isListening: Boolean,
    isProcessing: Boolean,
    isSpeaking: Boolean,
    activeText: String
) {
    val transition = rememberInfiniteTransition(label = "pulse")
    
    // Smooth, organic pulse for the main aura body
    val basePulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )
    
    // Smooth scale adjustment based on state
    val stateScale by animateFloatAsState(
        targetValue = when {
            isProcessing -> 1.25f
            isSpeaking -> 1.15f
            isListening -> 1.05f
            else -> 1.0f
        },
        animationSpec = tween(500, easing = LinearOutSlowInEasing),
        label = "state_scale"
    )

    val scalePulse = basePulse * stateScale
    
    // Secondary shimmer for the outer edges to create depth
    val baseShimmer by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmer_pulse"
    )
    
    val shimmerPulse = baseShimmer * stateScale

    val coreColor by animateColorAsState(targetValue = mode.color, label = "color_trans")

    Canvas(
        modifier = Modifier
            .size(340.dp)
            .testTag("core_visualizer_canvas")
    ) {
        val center = this.center
        val maxRadius = size.minDimension / 2f
        
        // Intensity boosters based on active state
        val alphaBoost = if (isSpeaking || isListening) 1.5f else 1.0f
        val radiusBoost = if (isSpeaking || isListening) 1.15f else 1.0f

        // Outer Aura (Wide, soft fade)
        val outerAuraRadius = (maxRadius * shimmerPulse * radiusBoost).coerceAtLeast(1f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    coreColor.copy(alpha = 0.15f * alphaBoost),
                    coreColor.copy(alpha = 0.05f * alphaBoost),
                    Color.Transparent
                ),
                center = center,
                radius = outerAuraRadius
            ),
            radius = outerAuraRadius,
            center = center
        )

        // Middle Aura (Denser layer that pulses with speech)
        val middleAuraRadius = (maxRadius * 0.75f * scalePulse * radiusBoost).coerceAtLeast(1f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    coreColor.copy(alpha = 0.45f * alphaBoost),
                    coreColor.copy(alpha = 0.15f * alphaBoost),
                    Color.Transparent
                ),
                center = center,
                radius = middleAuraRadius
            ),
            radius = middleAuraRadius,
            center = center
        )

        // Inner Core Glow (Intense, bright center)
        val innerCoreRadius = (maxRadius * 0.4f * (if (isSpeaking) scalePulse else 1f)).coerceAtLeast(1f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    coreColor.copy(alpha = 0.9f),
                    Color.Transparent
                ),
                center = center,
                radius = innerCoreRadius
            ),
            radius = innerCoreRadius,
            center = center
        )
        
        // Add dynamic energy ring when processing
        if (isProcessing) {
            drawCircle(
                color = coreColor.copy(alpha = 0.5f),
                radius = middleAuraRadius * 1.05f,
                center = center,
                style = Stroke(width = 6.dp.toPx())
            )
        }
    }
}

@Composable
fun HistoryLogCard(log: VoiceCommandLog, activeThemeMode: PyboxMode) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F1528))
            .border(1.dp, Color(0xFF1E2744), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (log.actionType.uppercase()) {
                            "OPEN_APP" -> Icons.Default.PlayArrow
                            "CALL_PHONE" -> Icons.Default.Phone
                            "SEND_MESSAGE" -> Icons.Default.Email
                            "CONTROL_SETTING" -> Icons.Default.Build
                            "WEB_SEARCH" -> Icons.Default.Search
                            "SWITCH_MODE" -> Icons.Default.Settings
                            else -> Icons.Default.Info
                        },
                        contentDescription = "Action type marker",
                        tint = activeThemeMode.color,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = log.actionType,
                        color = activeThemeMode.color,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = log.mode,
                    color = Color.Gray,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Heard: \"${log.textSpoken}\"",
                color = Color.White,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "Response: ${log.responseText}",
                color = Color.LightGray,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
