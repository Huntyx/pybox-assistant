package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class PyboxVoiceService : Service() {

    companion object {
        private const val TAG = "PyboxVoiceService"
        private const val CHANNEL_ID = "PyboxVoiceServiceChannel"
        private const val NOTIFICATION_ID = 2026
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_TOGGLE_PAUSE = "ACTION_TOGGLE_PAUSE"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var recognizerIntent: Intent? = null
    private var isListeningLoopActive = false
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var restartJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service Created")
        createNotificationChannel()
        PyboxEngine.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        Log.d(TAG, "onStartCommand action: $action")

        when (action) {
            ACTION_START -> {
                startForegroundServiceWithNotification()
                initSpeechRecognizer()
                startListeningLoop()
            }
            ACTION_STOP -> {
                stopListeningLoop()
                stopSelf()
            }
            ACTION_TOGGLE_PAUSE -> {
                if (isListeningLoopActive) {
                    stopListeningLoop()
                    PyboxEngine.speak("Active listening paused.")
                } else {
                    startListeningLoop()
                    PyboxEngine.speak("Active listening restored.")
                }
                updateNotification()
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        val notification = createNotification()
        // Standard Android declaration of foreground service microphone type is required
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, createNotification())
    }

    private fun createNotification(): Notification {
        val intentStop = Intent(this, PyboxVoiceService::class.java).apply { action = ACTION_STOP }
        val pendingStop = PendingIntent.getService(this, 1, intentStop, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val intentToggle = Intent(this, PyboxVoiceService::class.java).apply { action = ACTION_TOGGLE_PAUSE }
        val pendingToggle = PendingIntent.getService(this, 2, intentToggle, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val intentLaunch = Intent(this, MainActivity::class.java)
        val pendingLaunch = PendingIntent.getActivity(this, 0, intentLaunch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val modeText = PyboxEngine.currentMode.value.displayName
        val details = if (isListeningLoopActive) "Continuous Listening Active | Mode: $modeText" else "Listening Paused | Mode: $modeText"
        val stateActionText = if (isListeningLoopActive) "Pause Listening" else "Resume Listening"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pybox Cybernetic Core")
            .setContentText(details)
            .setSmallIcon(android.R.drawable.presence_online)
            .setContentIntent(pendingLaunch)
            .setStyle(NotificationCompat.BigTextStyle().bigText("Continuous voice response activated. Say 'Pybox ...' followed by your command at any time."))
            .addAction(android.R.drawable.ic_media_pause, stateActionText, pendingToggle)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Shutdown", pendingStop)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Pybox Background Monitor",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    private fun initSpeechRecognizer() {
        if (speechRecognizer != null) return

        try {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                Log.e(TAG, "Speech recognition not available on this device!")
                PyboxEngine.speak("Continuous voice system is not supported by this device's speech engine, fallback to tactile execution is active.")
                return
            }

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Log.d(TAG, "onReadyForSpeech")
                        PyboxEngine.setListening(true)
                    }

                    override fun onBeginningOfSpeech() {
                        Log.d(TAG, "onBeginningOfSpeech")
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Could update amplitude if wanted for canvas animation
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        Log.d(TAG, "onEndOfSpeech")
                        PyboxEngine.setListening(false)
                    }

                    override fun onError(error: Int) {
                        Log.e(TAG, "SpeechRecognizer Error: $error")
                        PyboxEngine.setListening(false)
                        
                        // Restart listening on errors unless loop was explicitly stopped
                        if (isListeningLoopActive) {
                            val restartDelay = when (error) {
                                SpeechRecognizer.ERROR_CLIENT, 
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 2500L
                                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
                                SpeechRecognizer.ERROR_NO_MATCH -> 500L
                                else -> 1000L
                            }
                            scheduleRecognizerRestart(restartDelay)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        PyboxEngine.setListening(false)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val resultText = matches?.getOrNull(0) ?: ""
                        Log.d(TAG, "onResults: $resultText")

                        if (resultText.isNotEmpty()) {
                            processInputString(resultText)
                        }

                        if (isListeningLoopActive) {
                            scheduleRecognizerRestart(500)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partialText = matches?.getOrNull(0) ?: ""
                        if (partialText.isNotEmpty()) {
                            PyboxEngine.updateActiveCommandText(partialText)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize SpeechRecognizer safely: ${e.message}", e)
            speechRecognizer = null
            PyboxEngine.speak("Speech recognition engine initialization skipped. Screen interface is active.")
        }
    }

    private fun processInputString(input: String) {
        val lower = input.lowercase(Locale.ROOT)
        val triggerKeywords = listOf("pybox", "piebox", "py box", "pie box", "pipeline", "firefox", "by box", "high box", "hi box", "five box")
        
        var foundTrigger = false
        var extractedCommand = ""

        for (k in triggerKeywords) {
            if (lower.contains(k)) {
                foundTrigger = true
                val index = lower.indexOf(k)
                extractedCommand = input.substring(index + k.length).trim()
                if (extractedCommand.startsWith(",") || extractedCommand.startsWith(":") || extractedCommand.startsWith("-")) {
                    extractedCommand = extractedCommand.substring(1).trim()
                }
                break
            }
        }

        if (foundTrigger && extractedCommand.isNotEmpty()) {
            PyboxEngine.processCommand(this@PyboxVoiceService, extractedCommand)
        } else {
            // What if we don't match the hotword, but the user is currently in direct conversation mode?
            // To ensure 100% beautiful usability in short-range tests, if active command text is being edited,
            // we let command flow execute if the word count is small, or log it cleanly.
            Log.d(TAG, "Heard speech without Pybox keyword activation: $input")
        }
    }

    private fun startListeningLoop() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Mic permission missing, cannot start listening loop!")
            return
        }
        isListeningLoopActive = true
        PyboxEngine.setListening(true)
        serviceScope.launch {
            delay(150)
            triggerRecognizerListening()
        }
    }

    private fun stopListeningLoop() {
        isListeningLoopActive = false
        restartJob?.cancel()
        speechRecognizer?.cancel()
        PyboxEngine.setListening(false)
    }

    private fun triggerRecognizerListening() {
        if (!isListeningLoopActive || speechRecognizer == null || recognizerIntent == null) return
        try {
            // Avoid cancelling the recognizer aggressively as it can cause DeadObject/IPC freezes
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error in startListening: ${e.message}")
            scheduleRecognizerRestart(2500L)
        }
    }

    private fun scheduleRecognizerRestart(delayMs: Long) {
        val safeDelay = delayMs.coerceAtLeast(1500L) // Enforce minimum 1.5s delay to prevent IPC flooding and freezes
        restartJob?.cancel()
        restartJob = serviceScope.launch {
            delay(safeDelay)
            if (isListeningLoopActive) {
                try {
                    speechRecognizer?.cancel()
                    speechRecognizer?.destroy()
                } catch (e: Exception) {
                    Log.e(TAG, "Error cleaning up recognizer: ${e.message}")
                }
                speechRecognizer = null
                initSpeechRecognizer()
                triggerRecognizerListening()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Service Destroyed")
        stopListeningLoop()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
