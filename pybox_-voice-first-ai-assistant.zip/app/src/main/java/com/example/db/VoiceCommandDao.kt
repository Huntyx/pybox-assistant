package com.example.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceCommandDao {
    @Query("SELECT * FROM voice_command_logs ORDER BY timestamp DESC LIMIT 50")
    fun getAllLogs(): Flow<List<VoiceCommandLog>>

    @Insert
    suspend fun insertLog(log: VoiceCommandLog)

    @Query("DELETE FROM voice_command_logs")
    suspend fun clearLogs()
}
