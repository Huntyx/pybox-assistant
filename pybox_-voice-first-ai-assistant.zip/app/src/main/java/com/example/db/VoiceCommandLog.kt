package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_command_logs")
data class VoiceCommandLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val textSpoken: String,
    val responseText: String,
    val mode: String,
    val actionType: String,
    val actionTarget: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SUCCESS"
)
