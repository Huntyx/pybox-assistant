package com.example.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [VoiceCommandLog::class], version = 1, exportSchema = false)
abstract class PyboxDatabase : RoomDatabase() {
    abstract fun commandDao(): VoiceCommandDao

    companion object {
        @Volatile
        private var INSTANCE: PyboxDatabase? = null

        fun getDatabase(context: Context): PyboxDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PyboxDatabase::class.java,
                    "pybox_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
